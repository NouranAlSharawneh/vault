import { describe, expect, it } from "vitest";
import { resolveAssetRequest } from "@main/app/protocol/resolve-asset-request";
import { insideVault } from "@main/services/fs/paths";

const ROOT = "/vault";
const ask = (href: string, present: string[] = []): ReturnType<typeof resolveAssetRequest> =>
  resolveAssetRequest(ROOT, new URL(href), (p) => present.includes(p), insideVault);

describe("vault://asset", () => {
  it("serves a file inside the vault with its media type", () => {
    const where = ask("vault://asset/atlas-api/assets/diagram.png", ["/vault/atlas-api/assets/diagram.png"]);

    expect(where).toEqual({ path: "/vault/atlas-api/assets/diagram.png", mime: "image/png" });
  });

  it("decodes the path, so a space in a filename still resolves", () => {
    const where = ask("vault://asset/inbox/assets/my%20shot.png", ["/vault/inbox/assets/my shot.png"]);

    expect(where).toEqual({ path: "/vault/inbox/assets/my shot.png", mime: "image/png" });
  });

  it("refuses a path that climbs out of the vault", () => {
    expect(ask("vault://asset/../../etc/hosts.png")).toEqual({ deny: 403 });
    expect(ask("vault://asset/atlas/../../secrets.png")).toEqual({ deny: 403 });
  });

  it("refuses anything in the repo's own .git folder", () => {
    // It is inside the vault and `config` has no extension, but the rule is explicit:
    // nothing under .git is ever served, whatever it is called.
    expect(ask("vault://asset/.git/hooks/evil.svg", ["/vault/.git/hooks/evil.svg"])).toEqual({
      deny: 403,
    });
  });

  it("refuses a file type it does not know how to serve", () => {
    expect(ask("vault://asset/inbox/notes.md", ["/vault/inbox/notes.md"])).toEqual({ deny: 403 });
    expect(ask("vault://asset/inbox/run.sh", ["/vault/inbox/run.sh"])).toEqual({ deny: 403 });
  });

  it("ignores a request aimed at some other host", () => {
    const where = resolveAssetRequest(
      ROOT,
      new URL("vault://elsewhere/inbox/a.png"),
      () => true,
      insideVault,
    );

    expect(where).toEqual({ deny: 404 });
  });

  it("serves nothing when no vault is open", () => {
    expect(resolveAssetRequest(undefined, new URL("vault://asset/a.png"), () => true, insideVault))
      .toEqual({ deny: 404 });
  });

  it("finds a trashed doc's image where the doc used to live", () => {
    // Trashing moves the document but deliberately leaves `assets/` behind, so the
    // reader for a trashed doc asks for a path that only exists one folder up.
    const where = ask("vault://asset/.trash/atlas/assets/shot.png", ["/vault/atlas/assets/shot.png"]);

    expect(where).toEqual({ path: "/vault/atlas/assets/shot.png", mime: "image/png" });
  });

  it("prefers the trashed copy when the image went into the trash too", () => {
    const where = ask("vault://asset/.trash/atlas/assets/shot.png", [
      "/vault/.trash/atlas/assets/shot.png",
      "/vault/atlas/assets/shot.png",
    ]);

    expect(where).toEqual({ path: "/vault/.trash/atlas/assets/shot.png", mime: "image/png" });
  });

  it("is a 404, not a 403, when the path is allowed but the file is gone", () => {
    expect(ask("vault://asset/inbox/assets/missing.png")).toEqual({ deny: 404 });
  });
});
