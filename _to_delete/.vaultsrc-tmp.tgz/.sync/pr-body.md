## What

⌘Y, or the toolbar button, opens every commit that touched the document, what each one changed, and a way back. Escape closes it.

- **Commit list** — message and relative time, newest first, opening on the latest change rather than an empty panel.
- **Diff** — the selected commit's unified diff with line numbers and a `+n −n` summary, parsed into typed lines rather than dumped as text.
- **Restore** — writes a **new commit**; history is never rewritten, so the version you moved away from stays reachable. The drawer reloads afterwards, since that restore is itself a commit its list was missing.

## The part worth reviewing

Moving a document between projects is a `git mv`, so **a commit's path is not always the document's path today**. `git log --follow --name-only` now carries the name each commit knew, and reading, diffing and restoring all use it.

Without that, asking for today's path at an older commit looks up a file that did not exist yet: the history list would render fine while everything built on it failed — and only for documents that had moved project. A fresh fixture never hits it; a real vault does. There's a test that creates a doc, moves it, and then reads, diffs and restores across the move.

## Also

- Reader toolbar buttons are icons with tooltips. Labelled ones ran into each other once the drawer took its share of the width.
- Fixed a genuinely flaky web-flow test. It raced a flow to completion before the second call could join it, so it sometimes asserted nothing at all. The redirect is held back now, making the join deterministic — it had failed twice across the session before I stopped treating it as noise.

## Verification

175 unit tests, full smoke, 0 console errors. The smoke drives the real thing: opens the drawer, asserts the diff shows the document's own content, closes it with Escape and reopens it, edits the document to create a second version, restores the older one, and checks **the file on disk actually reverted** and that the restore appears as a new `update:` commit.

One thing the smoke now checks explicitly: the drawer is **visible**, not merely mounted. The first version was nested inside the reader's card, which has `overflow-hidden` — it rendered, every assertion passed, and nothing was on screen. My first attempt at that check queried `aside`, which matched the sidebar instead, so it passed trivially too.

## Note

`f4226d7` on this branch ("stop reserving traffic-light space on non-mac") is not mine — another session committed it here while I was working.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_0126PDG4823ZnRqwM1TxGMWW
